from MDML_client import *
exp = experiment('FSP','test','testtest','merf.egs.anl.gov')
exp.replay_experiment('FSP_11.tar.gz')